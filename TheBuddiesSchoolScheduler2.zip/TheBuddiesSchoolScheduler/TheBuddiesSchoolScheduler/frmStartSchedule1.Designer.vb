﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStartSchedule1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(21, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(184, 43)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Class List"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(265, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Semester"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Fall 2013", "Spring 2014", "Summer 2014", "Fall 2014", "Spring 2015", "Summer 2015"})
        Me.ComboBox1.Location = New System.Drawing.Point(269, 46)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 3
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 25
        Me.ListBox1.Items.AddRange(New Object() {"CSCI027" & Global.Microsoft.VisualBasic.ChrW(9) & "ACM Student Chapter" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI148" & Global.Microsoft.VisualBasic.ChrW(9) & "Educational Technology" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI149" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Concepts for Business" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI150" & Global.Microsoft.VisualBasic.ChrW(9) & "Introduction to Computers" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI157" & Global.Microsoft.VisualBasic.ChrW(9) & "Database Applications" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI190" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Concepts w/Programming" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI191" & Global.Microsoft.VisualBasic.ChrW(9) & "Visual Basic Programming" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI192" & Global.Microsoft.VisualBasic.ChrW(9) & "Introductory Java Programming" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI241" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Software Design II" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI270" & Global.Microsoft.VisualBasic.ChrW(9) & "Web Page Development" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI299" & Global.Microsoft.VisualBasic.ChrW(9) & "Topics In Comp Sci & Technology", "CSCI300" & Global.Microsoft.VisualBasic.ChrW(9) & "Discrete Structures" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI325" & Global.Microsoft.VisualBasic.ChrW(9) & "Operating Systems" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI355" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Organization" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI416" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer & Network Forensics" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI445" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Networking" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI460" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Systems Administration" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI480" & Global.Microsoft.VisualBasic.ChrW(9) & "Software Engineering" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI498" & Global.Microsoft.VisualBasic.ChrW(9) & "Internship in Computer Science" & Global.Microsoft.VisualBasic.ChrW(9)})
        Me.ListBox1.Location = New System.Drawing.Point(28, 83)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(447, 479)
        Me.ListBox1.TabIndex = 4
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(481, 155)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(39, 20)
        Me.TextBox1.TabIndex = 5
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(481, 129)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(39, 20)
        Me.TextBox2.TabIndex = 6
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(481, 178)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(39, 20)
        Me.TextBox3.TabIndex = 7
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(481, 103)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(39, 20)
        Me.TextBox4.TabIndex = 8
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(481, 204)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(39, 20)
        Me.TextBox5.TabIndex = 9
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(481, 77)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(39, 20)
        Me.TextBox6.TabIndex = 10
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(481, 230)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(39, 20)
        Me.TextBox7.TabIndex = 11
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(481, 256)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(39, 20)
        Me.TextBox9.TabIndex = 13
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(481, 282)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(39, 20)
        Me.TextBox11.TabIndex = 15
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(481, 308)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(39, 20)
        Me.TextBox13.TabIndex = 17
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(481, 334)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(39, 20)
        Me.TextBox15.TabIndex = 19
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(481, 360)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(39, 20)
        Me.TextBox17.TabIndex = 21
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(481, 386)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(39, 20)
        Me.TextBox19.TabIndex = 23
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(481, 412)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(39, 20)
        Me.TextBox21.TabIndex = 25
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(481, 438)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(39, 20)
        Me.TextBox23.TabIndex = 27
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(481, 464)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(39, 20)
        Me.TextBox25.TabIndex = 29
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(481, 490)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(39, 20)
        Me.TextBox27.TabIndex = 31
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(481, 516)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(39, 20)
        Me.TextBox29.TabIndex = 33
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(481, 542)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(39, 20)
        Me.TextBox31.TabIndex = 35
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(478, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "Sections"
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(18, 573)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(151, 23)
        Me.btnBack.TabIndex = 41
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(219, 573)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(151, 23)
        Me.btnCancel.TabIndex = 42
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(420, 573)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(151, 23)
        Me.btnNext.TabIndex = 43
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(539, 54)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 63
        Me.Label5.Text = "Online"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(537, 542)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(39, 20)
        Me.TextBox8.TabIndex = 62
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(537, 516)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(39, 20)
        Me.TextBox10.TabIndex = 61
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(537, 490)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(39, 20)
        Me.TextBox12.TabIndex = 60
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(537, 464)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(39, 20)
        Me.TextBox14.TabIndex = 59
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(537, 438)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(39, 20)
        Me.TextBox16.TabIndex = 58
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(537, 412)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(39, 20)
        Me.TextBox18.TabIndex = 57
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(537, 386)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(39, 20)
        Me.TextBox20.TabIndex = 56
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(537, 360)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(39, 20)
        Me.TextBox22.TabIndex = 55
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(537, 334)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(39, 20)
        Me.TextBox24.TabIndex = 54
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(537, 308)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(39, 20)
        Me.TextBox26.TabIndex = 53
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(537, 282)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(39, 20)
        Me.TextBox28.TabIndex = 52
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(537, 256)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(39, 20)
        Me.TextBox30.TabIndex = 51
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(537, 230)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(39, 20)
        Me.TextBox32.TabIndex = 50
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(537, 77)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(39, 20)
        Me.TextBox33.TabIndex = 49
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(537, 204)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(39, 20)
        Me.TextBox34.TabIndex = 48
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(537, 103)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(39, 20)
        Me.TextBox35.TabIndex = 47
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(537, 178)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(39, 20)
        Me.TextBox36.TabIndex = 46
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(537, 129)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(39, 20)
        Me.TextBox37.TabIndex = 45
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(537, 155)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(39, 20)
        Me.TextBox38.TabIndex = 44
        '
        'frmStartSchedule1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 608)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.TextBox28)
        Me.Controls.Add(Me.TextBox30)
        Me.Controls.Add(Me.TextBox32)
        Me.Controls.Add(Me.TextBox33)
        Me.Controls.Add(Me.TextBox34)
        Me.Controls.Add(Me.TextBox35)
        Me.Controls.Add(Me.TextBox36)
        Me.Controls.Add(Me.TextBox37)
        Me.Controls.Add(Me.TextBox38)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox31)
        Me.Controls.Add(Me.TextBox29)
        Me.Controls.Add(Me.TextBox27)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.TextBox23)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmStartSchedule1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "The Buddies Easy Scheduler"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
End Class
