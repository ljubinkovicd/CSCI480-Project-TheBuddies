﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStartSchedule2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(282, 43)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Professor Select"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox1.Location = New System.Drawing.Point(468, 123)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 47
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox2.Location = New System.Drawing.Point(468, 150)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 48
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox3.Location = New System.Drawing.Point(468, 177)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 49
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox4.Location = New System.Drawing.Point(468, 204)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 50
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox5.Location = New System.Drawing.Point(468, 231)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox5.TabIndex = 51
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox6.Location = New System.Drawing.Point(468, 258)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox6.TabIndex = 52
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox7.Location = New System.Drawing.Point(468, 285)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox7.TabIndex = 53
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox8.Location = New System.Drawing.Point(468, 312)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox8.TabIndex = 54
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox9.Location = New System.Drawing.Point(468, 339)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox9.TabIndex = 55
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox10.Location = New System.Drawing.Point(468, 366)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox10.TabIndex = 56
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox11.Location = New System.Drawing.Point(468, 393)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox11.TabIndex = 57
        '
        'ComboBox12
        '
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox12.Location = New System.Drawing.Point(468, 420)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox12.TabIndex = 58
        '
        'ComboBox13
        '
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox13.Location = New System.Drawing.Point(468, 447)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox13.TabIndex = 59
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox14.Location = New System.Drawing.Point(468, 474)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox14.TabIndex = 60
        '
        'ComboBox15
        '
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox15.Location = New System.Drawing.Point(468, 501)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox15.TabIndex = 61
        '
        'ComboBox16
        '
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox16.Location = New System.Drawing.Point(468, 528)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox16.TabIndex = 62
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(461, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 13)
        Me.Label3.TabIndex = 65
        Me.Label3.Text = "Please Select a Professor"
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 25
        Me.ListBox1.Items.AddRange(New Object() {"CSCI027" & Global.Microsoft.VisualBasic.ChrW(9) & "ACM Student Chapter" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI148" & Global.Microsoft.VisualBasic.ChrW(9) & "Educational Technology" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI149" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Concepts for Business" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI150" & Global.Microsoft.VisualBasic.ChrW(9) & "Introduction to Computers" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI157" & Global.Microsoft.VisualBasic.ChrW(9) & "Database Applications" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI190" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Concepts w/Programming" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI191" & Global.Microsoft.VisualBasic.ChrW(9) & "Visual Basic Programming" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI192" & Global.Microsoft.VisualBasic.ChrW(9) & "Introductory Java Programming" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI241" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Software Design II" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI270" & Global.Microsoft.VisualBasic.ChrW(9) & "Web Page Development" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI299" & Global.Microsoft.VisualBasic.ChrW(9) & "Topics In Comp Sci & Technology", "CSCI300" & Global.Microsoft.VisualBasic.ChrW(9) & "Discrete Structures" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI325" & Global.Microsoft.VisualBasic.ChrW(9) & "Operating Systems" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI355" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Organization" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI416" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer & Network Forensics" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI445" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Networking" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI460" & Global.Microsoft.VisualBasic.ChrW(9) & "Computer Systems Administration" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI480" & Global.Microsoft.VisualBasic.ChrW(9) & "Software Engineering" & Global.Microsoft.VisualBasic.ChrW(9), "CSCI498" & Global.Microsoft.VisualBasic.ChrW(9) & "Internship in Computer Science" & Global.Microsoft.VisualBasic.ChrW(9)})
        Me.ListBox1.Location = New System.Drawing.Point(12, 69)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(450, 479)
        Me.ListBox1.TabIndex = 66
        '
        'ComboBox17
        '
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox17.Location = New System.Drawing.Point(468, 69)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox17.TabIndex = 67
        '
        'ComboBox18
        '
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Items.AddRange(New Object() {"Baker", "Geise", "Gunnett", "Ringenberg", "Samimi", "Schneider", "Wardzala"})
        Me.ComboBox18.Location = New System.Drawing.Point(468, 96)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox18.TabIndex = 68
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(414, 573)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(151, 23)
        Me.btnNext.TabIndex = 71
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(213, 573)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(151, 23)
        Me.btnCancel.TabIndex = 70
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(12, 573)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(151, 23)
        Me.btnBack.TabIndex = 69
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'frmStartSchedule2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 608)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.ComboBox18)
        Me.Controls.Add(Me.ComboBox17)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ComboBox16)
        Me.Controls.Add(Me.ComboBox15)
        Me.Controls.Add(Me.ComboBox14)
        Me.Controls.Add(Me.ComboBox13)
        Me.Controls.Add(Me.ComboBox12)
        Me.Controls.Add(Me.ComboBox11)
        Me.Controls.Add(Me.ComboBox10)
        Me.Controls.Add(Me.ComboBox9)
        Me.Controls.Add(Me.ComboBox8)
        Me.Controls.Add(Me.ComboBox7)
        Me.Controls.Add(Me.ComboBox6)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmStartSchedule2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "The Buddies Easy Scheduler"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox8 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox12 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox13 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox15 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox16 As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ComboBox17 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox18 As System.Windows.Forms.ComboBox
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnBack As System.Windows.Forms.Button
End Class
