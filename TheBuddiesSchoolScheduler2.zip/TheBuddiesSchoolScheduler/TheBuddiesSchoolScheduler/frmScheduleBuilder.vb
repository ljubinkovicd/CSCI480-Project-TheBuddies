﻿Imports System
Imports System.Runtime.InteropServices
Imports System.Drawing
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.IO
Imports System.Xml.Serialization
Public Class frmScheduleBuilder

    Dim m_MouseIsDown As Boolean = False

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Visible = False
        frmWelcome.Visible = True
    End Sub

    Private Sub btnTeacher_Click(sender As Object, e As EventArgs) Handles btnTeacher.Click
        Me.Visible = False
        frmTeacherSchedule.Visible = True
    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs)
        Me.Visible = True
        frmClassSpecs.Visible = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Me.Visible = False
        frmReports.Visible = True
    End Sub


    Private Sub frmScheduleBuilder_Load(ByVal sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ' Enable dropping.
        ' Instead of a picture, this needs to be like an Excel grid where Geise can drop classes into certain fields.
        PictureBox2.AllowDrop = True
    End Sub

    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
        If Not PictureBox1.Image Is Nothing Then
            ' Set a flag to show that the mouse is down.
            m_MouseIsDown = True
        End If
    End Sub
    Private Sub PictureBox1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        If m_MouseIsDown Then
            ' Initiate dragging and allow copying.
            PictureBox1.DoDragDrop(PictureBox1.Image, DragDropEffects.Copy)
        End If
        m_MouseIsDown = False
    End Sub

    Private Sub PictureBox2_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox2.DragEnter
        If e.Data.GetDataPresent(DataFormats.Bitmap) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub PictureBox2_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox2.DragDrop
        ' Assign the image to the PictureBox.
        PictureBox2.Image = e.Data.GetData(DataFormats.Bitmap)
    End Sub


    ' These are for inserting just the label text into the ListView
    Private Sub Lab_MouseDown(ByVal Sender As Object, e As EventArgs) Handles PicBox1.MouseDown, PicBox2.MouseDown, PicBox3.MouseDown, PicBox4.MouseDown, PicBox5.MouseDown, PicBox6.MouseDown
        Dim Lab As Label
        Lab = CType(Sender, Label)

        Lab.DoDragDrop(Lab, DragDropEffects.Copy)
    End Sub

    Private Sub ListView1_DragEnter(ByVal Sender As Object, e As DragEventArgs) Handles ListView1.DragEnter
        Dim Lab As Label
        Lab = e.Data.GetData(GetType(Label))

        ListView1.Items.Add(Lab.Text)
    End Sub
End Class

