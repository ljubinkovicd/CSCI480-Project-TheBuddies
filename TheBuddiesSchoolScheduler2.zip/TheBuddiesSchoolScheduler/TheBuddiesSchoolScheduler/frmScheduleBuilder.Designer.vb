﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScheduleBuilder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmScheduleBuilder))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PicBox1 = New System.Windows.Forms.Label()
        Me.PicBox5 = New System.Windows.Forms.Label()
        Me.PicBox4 = New System.Windows.Forms.Label()
        Me.PicBox6 = New System.Windows.Forms.Label()
        Me.PicBox3 = New System.Windows.Forms.Label()
        Me.PicBox2 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.btnTeacher = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(376, 53)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Schedule Builder"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(160, 85)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(631, 327)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 4
        Me.PictureBox2.TabStop = False
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(832, 178)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 39)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "CSCI 027"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBox1
        '
        Me.PicBox1.BackColor = System.Drawing.Color.Maroon
        Me.PicBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicBox1.ForeColor = System.Drawing.Color.White
        Me.PicBox1.Location = New System.Drawing.Point(34, 85)
        Me.PicBox1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PicBox1.Name = "PicBox1"
        Me.PicBox1.Size = New System.Drawing.Size(89, 47)
        Me.PicBox1.TabIndex = 22
        Me.PicBox1.Text = "CSCI 149.01"
        Me.PicBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBox5
        '
        Me.PicBox5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PicBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicBox5.ForeColor = System.Drawing.Color.White
        Me.PicBox5.Location = New System.Drawing.Point(33, 350)
        Me.PicBox5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PicBox5.Name = "PicBox5"
        Me.PicBox5.Size = New System.Drawing.Size(89, 38)
        Me.PicBox5.TabIndex = 23
        Me.PicBox5.Text = "CSCI 325.01"
        Me.PicBox5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBox4
        '
        Me.PicBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.PicBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicBox4.ForeColor = System.Drawing.Color.White
        Me.PicBox4.Location = New System.Drawing.Point(33, 284)
        Me.PicBox4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PicBox4.Name = "PicBox4"
        Me.PicBox4.Size = New System.Drawing.Size(89, 38)
        Me.PicBox4.TabIndex = 24
        Me.PicBox4.Text = "CSCI 299.01"
        Me.PicBox4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBox6
        '
        Me.PicBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PicBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicBox6.ForeColor = System.Drawing.Color.Black
        Me.PicBox6.Location = New System.Drawing.Point(33, 410)
        Me.PicBox6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PicBox6.Name = "PicBox6"
        Me.PicBox6.Size = New System.Drawing.Size(89, 38)
        Me.PicBox6.TabIndex = 25
        Me.PicBox6.Text = "CSCI 416.01"
        Me.PicBox6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBox3
        '
        Me.PicBox3.BackColor = System.Drawing.Color.Green
        Me.PicBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicBox3.ForeColor = System.Drawing.Color.White
        Me.PicBox3.Location = New System.Drawing.Point(33, 215)
        Me.PicBox3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PicBox3.Name = "PicBox3"
        Me.PicBox3.Size = New System.Drawing.Size(89, 38)
        Me.PicBox3.TabIndex = 26
        Me.PicBox3.Text = "CSCI 241.01"
        Me.PicBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBox2
        '
        Me.PicBox2.BackColor = System.Drawing.Color.Black
        Me.PicBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicBox2.ForeColor = System.Drawing.Color.White
        Me.PicBox2.Location = New System.Drawing.Point(33, 150)
        Me.PicBox2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PicBox2.Name = "PicBox2"
        Me.PicBox2.Size = New System.Drawing.Size(89, 53)
        Me.PicBox2.TabIndex = 27
        Me.PicBox2.Text = "CSCI 192.01"
        Me.PicBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(16, 644)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(69, 20)
        Me.Label22.TabIndex = 28
        Me.Label22.Text = "Legend:"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(60, 674)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(27, 25)
        Me.Label23.TabIndex = 29
        Me.Label23.Text = " "
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label24.Location = New System.Drawing.Point(60, 713)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(27, 25)
        Me.Label24.TabIndex = 30
        Me.Label24.Text = " "
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(117, 674)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(80, 17)
        Me.Label25.TabIndex = 31
        Me.Label25.Text = "Brewer 108"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(117, 713)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(71, 17)
        Me.Label26.TabIndex = 32
        Me.Label26.Text = "Davis 196"
        '
        'btnTeacher
        '
        Me.btnTeacher.Location = New System.Drawing.Point(347, 688)
        Me.btnTeacher.Margin = New System.Windows.Forms.Padding(4)
        Me.btnTeacher.Name = "btnTeacher"
        Me.btnTeacher.Size = New System.Drawing.Size(100, 28)
        Me.btnTeacher.TabIndex = 33
        Me.btnTeacher.Text = "Teachers"
        Me.btnTeacher.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(515, 688)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(100, 28)
        Me.btnSave.TabIndex = 34
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(668, 688)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(100, 28)
        Me.btnCancel.TabIndex = 35
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(37, 476)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'ListView1
        '
        Me.ListView1.AllowDrop = True
        Me.ListView1.Location = New System.Drawing.Point(160, 419)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(631, 245)
        Me.ListView1.TabIndex = 37
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'frmScheduleBuilder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(819, 748)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnTeacher)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.PicBox2)
        Me.Controls.Add(Me.PicBox3)
        Me.Controls.Add(Me.PicBox6)
        Me.Controls.Add(Me.PicBox4)
        Me.Controls.Add(Me.PicBox5)
        Me.Controls.Add(Me.PicBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmScheduleBuilder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "The Buddies Easy Scheduler"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PicBox1 As System.Windows.Forms.Label
    Friend WithEvents PicBox5 As System.Windows.Forms.Label
    Friend WithEvents PicBox4 As System.Windows.Forms.Label
    Friend WithEvents PicBox6 As System.Windows.Forms.Label
    Friend WithEvents PicBox3 As System.Windows.Forms.Label
    Friend WithEvents PicBox2 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents btnTeacher As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
End Class
