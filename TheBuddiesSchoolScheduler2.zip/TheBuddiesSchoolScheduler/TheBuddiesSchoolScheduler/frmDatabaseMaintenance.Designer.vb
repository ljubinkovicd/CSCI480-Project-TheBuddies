﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDatabaseMaintenance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAddClass = New System.Windows.Forms.Button()
        Me.btnEditClass = New System.Windows.Forms.Button()
        Me.btnRemoveClass = New System.Windows.Forms.Button()
        Me.btnAddProfessor = New System.Windows.Forms.Button()
        Me.btnEditProfessor = New System.Windows.Forms.Button()
        Me.btnRemoveProfessor = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chk7 = New System.Windows.Forms.CheckBox()
        Me.chk6 = New System.Windows.Forms.CheckBox()
        Me.chk3 = New System.Windows.Forms.CheckBox()
        Me.chk1 = New System.Windows.Forms.CheckBox()
        Me.chk5 = New System.Windows.Forms.CheckBox()
        Me.chk4 = New System.Windows.Forms.CheckBox()
        Me.chk2 = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(21, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(385, 43)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Database Maintenance"
        '
        'btnAddClass
        '
        Me.btnAddClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddClass.Location = New System.Drawing.Point(28, 81)
        Me.btnAddClass.Name = "btnAddClass"
        Me.btnAddClass.Size = New System.Drawing.Size(222, 42)
        Me.btnAddClass.TabIndex = 2
        Me.btnAddClass.Text = "Add Class"
        Me.btnAddClass.UseVisualStyleBackColor = True
        '
        'btnEditClass
        '
        Me.btnEditClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditClass.Location = New System.Drawing.Point(28, 134)
        Me.btnEditClass.Name = "btnEditClass"
        Me.btnEditClass.Size = New System.Drawing.Size(222, 42)
        Me.btnEditClass.TabIndex = 3
        Me.btnEditClass.Text = "Edit Class"
        Me.btnEditClass.UseVisualStyleBackColor = True
        '
        'btnRemoveClass
        '
        Me.btnRemoveClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemoveClass.Location = New System.Drawing.Point(28, 187)
        Me.btnRemoveClass.Name = "btnRemoveClass"
        Me.btnRemoveClass.Size = New System.Drawing.Size(222, 42)
        Me.btnRemoveClass.TabIndex = 4
        Me.btnRemoveClass.Text = "Remove Class"
        Me.btnRemoveClass.UseVisualStyleBackColor = True
        '
        'btnAddProfessor
        '
        Me.btnAddProfessor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddProfessor.Location = New System.Drawing.Point(337, 81)
        Me.btnAddProfessor.Name = "btnAddProfessor"
        Me.btnAddProfessor.Size = New System.Drawing.Size(222, 42)
        Me.btnAddProfessor.TabIndex = 5
        Me.btnAddProfessor.Text = "Add Professor"
        Me.btnAddProfessor.UseVisualStyleBackColor = True
        '
        'btnEditProfessor
        '
        Me.btnEditProfessor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditProfessor.Location = New System.Drawing.Point(337, 134)
        Me.btnEditProfessor.Name = "btnEditProfessor"
        Me.btnEditProfessor.Size = New System.Drawing.Size(222, 42)
        Me.btnEditProfessor.TabIndex = 6
        Me.btnEditProfessor.Text = "Edit Professor"
        Me.btnEditProfessor.UseVisualStyleBackColor = True
        '
        'btnRemoveProfessor
        '
        Me.btnRemoveProfessor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemoveProfessor.Location = New System.Drawing.Point(337, 187)
        Me.btnRemoveProfessor.Name = "btnRemoveProfessor"
        Me.btnRemoveProfessor.Size = New System.Drawing.Size(222, 42)
        Me.btnRemoveProfessor.TabIndex = 7
        Me.btnRemoveProfessor.Text = "Remove Professor"
        Me.btnRemoveProfessor.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chk7)
        Me.GroupBox1.Controls.Add(Me.chk6)
        Me.GroupBox1.Controls.Add(Me.chk3)
        Me.GroupBox1.Controls.Add(Me.chk1)
        Me.GroupBox1.Controls.Add(Me.chk5)
        Me.GroupBox1.Controls.Add(Me.chk4)
        Me.GroupBox1.Controls.Add(Me.chk2)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.TextBox8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.TextBox7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.TextBox6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.TextBox5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TextBox4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.TextBox3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 243)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(590, 220)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        Me.GroupBox1.Visible = False
        '
        'chk7
        '
        Me.chk7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk7.Location = New System.Drawing.Point(553, 169)
        Me.chk7.Name = "chk7"
        Me.chk7.Size = New System.Drawing.Size(30, 44)
        Me.chk7.TabIndex = 23
        Me.chk7.Text = "7"
        Me.chk7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk7.UseVisualStyleBackColor = True
        Me.chk7.Visible = False
        '
        'chk6
        '
        Me.chk6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk6.Location = New System.Drawing.Point(523, 169)
        Me.chk6.Name = "chk6"
        Me.chk6.Size = New System.Drawing.Size(30, 44)
        Me.chk6.TabIndex = 22
        Me.chk6.Text = "6"
        Me.chk6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk6.UseVisualStyleBackColor = True
        Me.chk6.Visible = False
        '
        'chk3
        '
        Me.chk3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk3.Location = New System.Drawing.Point(433, 169)
        Me.chk3.Name = "chk3"
        Me.chk3.Size = New System.Drawing.Size(30, 44)
        Me.chk3.TabIndex = 21
        Me.chk3.Text = "3"
        Me.chk3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk3.UseVisualStyleBackColor = True
        Me.chk3.Visible = False
        '
        'chk1
        '
        Me.chk1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk1.Location = New System.Drawing.Point(373, 169)
        Me.chk1.Name = "chk1"
        Me.chk1.Size = New System.Drawing.Size(30, 44)
        Me.chk1.TabIndex = 20
        Me.chk1.Text = "1"
        Me.chk1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk1.UseVisualStyleBackColor = True
        Me.chk1.Visible = False
        '
        'chk5
        '
        Me.chk5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk5.Location = New System.Drawing.Point(493, 169)
        Me.chk5.Name = "chk5"
        Me.chk5.Size = New System.Drawing.Size(30, 44)
        Me.chk5.TabIndex = 19
        Me.chk5.Text = "5"
        Me.chk5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk5.UseVisualStyleBackColor = True
        Me.chk5.Visible = False
        '
        'chk4
        '
        Me.chk4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk4.Location = New System.Drawing.Point(463, 169)
        Me.chk4.Name = "chk4"
        Me.chk4.Size = New System.Drawing.Size(30, 44)
        Me.chk4.TabIndex = 18
        Me.chk4.Text = "4"
        Me.chk4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk4.UseVisualStyleBackColor = True
        Me.chk4.Visible = False
        '
        'chk2
        '
        Me.chk2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chk2.Location = New System.Drawing.Point(403, 169)
        Me.chk2.Name = "chk2"
        Me.chk2.Size = New System.Drawing.Size(30, 44)
        Me.chk2.TabIndex = 17
        Me.chk2.Text = "2"
        Me.chk2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chk2.UseVisualStyleBackColor = True
        Me.chk2.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(442, 157)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 13)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "Label10"
        Me.Label10.Visible = False
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(442, 110)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 15
        Me.TextBox8.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(442, 94)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(39, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Label9"
        Me.Label9.Visible = False
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(442, 47)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 13
        Me.TextBox7.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(439, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Label8"
        Me.Label8.Visible = False
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(241, 173)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 11
        Me.TextBox6.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(241, 157)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Label7"
        Me.Label7.Visible = False
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(241, 110)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 9
        Me.TextBox5.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(241, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Label6"
        Me.Label6.Visible = False
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(241, 47)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 7
        Me.TextBox4.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(238, 31)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Label5"
        Me.Label5.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(16, 174)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 5
        Me.TextBox3.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 157)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Label4"
        Me.Label4.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(16, 111)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 3
        Me.TextBox2.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Label3"
        Me.Label3.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(16, 48)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Label2"
        Me.Label2.Visible = False
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(140, 473)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 9
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(253, 473)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(358, 473)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 11
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmDatabaseMaintenance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 508)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnRemoveProfessor)
        Me.Controls.Add(Me.btnEditProfessor)
        Me.Controls.Add(Me.btnAddProfessor)
        Me.Controls.Add(Me.btnRemoveClass)
        Me.Controls.Add(Me.btnEditClass)
        Me.Controls.Add(Me.btnAddClass)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmDatabaseMaintenance"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "The Buddies Easy Scheduler"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnAddClass As System.Windows.Forms.Button
    Friend WithEvents btnEditClass As System.Windows.Forms.Button
    Friend WithEvents btnRemoveClass As System.Windows.Forms.Button
    Friend WithEvents btnAddProfessor As System.Windows.Forms.Button
    Friend WithEvents btnEditProfessor As System.Windows.Forms.Button
    Friend WithEvents btnRemoveProfessor As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chk7 As System.Windows.Forms.CheckBox
    Friend WithEvents chk6 As System.Windows.Forms.CheckBox
    Friend WithEvents chk3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk1 As System.Windows.Forms.CheckBox
    Friend WithEvents chk5 As System.Windows.Forms.CheckBox
    Friend WithEvents chk4 As System.Windows.Forms.CheckBox
    Friend WithEvents chk2 As System.Windows.Forms.CheckBox
End Class
